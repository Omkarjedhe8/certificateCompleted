package com.renocrewsolutions.certificategenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CertificateGenerator1Application {

	public static void main(String[] args) {
		SpringApplication.run(CertificateGenerator1Application.class, args);
	}

}
