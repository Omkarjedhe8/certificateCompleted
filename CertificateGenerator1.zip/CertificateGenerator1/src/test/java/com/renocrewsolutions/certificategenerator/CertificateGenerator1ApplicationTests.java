package com.renocrewsolutions.certificategenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CertificateGenerator1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
